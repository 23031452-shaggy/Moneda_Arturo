package Views;
import Controllers.*;
public class Instrumentos
{
    public static void main(String[] args)
    {
        InstrumentosController controller = new InstrumentosController();
        controller.iniciarSistema();
    }
}
