package Models;

public interface Instrumento <T>
{
    void afinar(T afinacion);
    void tocar();
}
