public interface Figura
{
    void dibujar();
}