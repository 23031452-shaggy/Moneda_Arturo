public class Cuadrado implements Figura
{
    @Override
    public void dibujar()
    {
        System.out.println("Estoy dibujando un cuadrado");
    }
}
