public class Triangulo implements Figura
{
    @Override
    public void dibujar()
    {
        System.out.println("Estoy dibujando un triangulo");
    }
}
