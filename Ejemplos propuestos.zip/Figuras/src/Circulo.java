public class Circulo implements Figura
{
    @Override
    public void dibujar()
    {
        System.out.println("Estoy dibujando un circulo");
    }
}
