public interface Vehiculo
{
    void conducir();
}