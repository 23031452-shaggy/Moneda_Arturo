public class Camion implements Vehiculo
{
    @Override
    public void conducir()
    {
        System.out.println("Conduciendo un camion");
    }
}
