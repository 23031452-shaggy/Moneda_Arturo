package com.example.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
//BUILDER
public class UsuarioBuilder {
    private int id;
    private String username;
    private String correo;
    private String passwordHash;
    private LocalDateTime fechaRegistro;
    private String nombreCompleto;
    private LocalDate fechaNacimiento;

    private UsuarioBuilder(Builder b) {
        this.id = b.id;
        this.username = b.usuario;
        this.correo = b.correo;
        this.passwordHash = b.passwordHash;
        this.fechaRegistro = b.fechaRegistro;
        this.nombreCompleto = b.nombreCompleto;
        this.fechaNacimiento = b.fechaNacimiento;
    }

    public static class Builder {
        private int id;
        private String usuario;
        private String correo;
        private String passwordHash;
        private LocalDateTime fechaRegistro;
        private String nombreCompleto;
        private LocalDate fechaNacimiento;

        public Builder setId(int id) { this.id = id; return this; }
        public Builder setUsuario(String usuario) { this.usuario = usuario; return this; }
        public Builder setCorreo(String correo) { this.correo = correo; return this; }
        public Builder setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; return this; }
        public Builder setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; return this; }
        public Builder setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; return this; }
        public Builder setFechaNacimiento(LocalDate fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; return this; }

        public UsuarioBuilder build() { return new UsuarioBuilder(this); }
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getCorreo() { return correo; }
    public String getPasswordHash() { return passwordHash; }
    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public String getNombreCompleto() { return nombreCompleto; }
    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
}
