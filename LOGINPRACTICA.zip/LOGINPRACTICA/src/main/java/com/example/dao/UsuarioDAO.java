package com.example.dao;

import com.example.model.UsuarioBuilder;

import java.sql.*;

public class UsuarioDAO implements InterfazDAO {
    private final Connection conn;

    public UsuarioDAO() throws SQLException {
        this.conn = ConexionDBSingleton.getInstance().getConnection();
    }

    @Override
    public boolean insert(UsuarioBuilder usuarioBuilder) throws SQLException {
        String sql = "INSERT INTO usuarios (username, correo, password_hash, nombre_completo, fecha_nacimiento) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, usuarioBuilder.getUsername());
        ps.setString(2, usuarioBuilder.getCorreo());
        ps.setString(3, usuarioBuilder.getPasswordHash());
        ps.setString(4, usuarioBuilder.getNombreCompleto());
        ps.setDate(5, Date.valueOf(usuarioBuilder.getFechaNacimiento()));
        return ps.executeUpdate() > 0;
    }

    @Override
    public UsuarioBuilder findByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE username = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? mapUser(rs) : null;
    }

    @Override
    public UsuarioBuilder findByCorreo(String correo) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE correo = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, correo);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? mapUser(rs) : null;
    }

    @Override
    public UsuarioBuilder findByUsernameOrCorreo(String dato) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE username = ? OR correo = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, dato);
        ps.setString(2, dato);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? mapUser(rs) : null;
    }

    private UsuarioBuilder mapUser(ResultSet rs) throws SQLException {
        return new UsuarioBuilder.Builder()
                .setId(rs.getInt("id"))
                .setUsuario(rs.getString("username"))
                .setCorreo(rs.getString("correo"))
                .setPasswordHash(rs.getString("password_hash"))
                .setNombreCompleto(rs.getString("nombre_completo"))
                .setFechaNacimiento(rs.getDate("fecha_nacimiento").toLocalDate())
                .setFechaRegistro(rs.getTimestamp("fecha_registro").toLocalDateTime())
                .build();
    }
}
