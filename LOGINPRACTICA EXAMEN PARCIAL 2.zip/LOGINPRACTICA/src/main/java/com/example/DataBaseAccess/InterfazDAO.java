package com.example.DataBaseAccess;
import com.example.model.UsuarioBuilder;

import java.sql.SQLException;

public interface InterfazDAO {
    boolean insert(UsuarioBuilder usuarioBuilder) throws SQLException;
    UsuarioBuilder findByUsername(String username) throws SQLException;
    UsuarioBuilder findByCorreo(String correo) throws SQLException;
    UsuarioBuilder findByUsernameOrCorreo(String dato) throws SQLException;
}
