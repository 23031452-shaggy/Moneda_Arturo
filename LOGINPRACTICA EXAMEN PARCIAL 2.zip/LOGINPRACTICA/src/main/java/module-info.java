module crypto.loginpractica {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;
    requires java.sql;
    requires jbcrypt;
    requires mysql.connector.j;

    opens com.example to javafx.fxml;
    exports com.example;
    exports com.example.view;
    exports com.example.controller;
    exports com.example.model;
    exports com.example.DataBaseAccess;
}