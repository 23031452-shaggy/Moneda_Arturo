package com.example.Controllers;

import com.example.DBAccess.BusquedaDAO;
import com.example.Models.City;
import com.example.Models.Country;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Controller {

    private final BusquedaDAO dao;

    public Controller() {
        this.dao = new BusquedaDAO();
    }

    public ObservableList<String> obtenerContinentes() {
        return FXCollections.observableArrayList(dao.getContinents());
    }

    public ObservableList<Country> buscarPaises(String continente, String nombre) {
        return FXCollections.observableArrayList(dao.buscarCountries(continente, nombre));
    }

    public ObservableList<City> obtenerCiudades(Country pais) {
        if (pais == null) return FXCollections.emptyObservableList();
        return FXCollections.observableArrayList(dao.getCitiesCountry(pais.getCode()));
    }
}
