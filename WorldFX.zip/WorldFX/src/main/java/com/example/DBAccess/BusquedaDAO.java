package com.example.DBAccess;

import com.example.Models.City;
import com.example.Models.Country;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BusquedaDAO {

    private final Connection conn;

    public BusquedaDAO() {
        try {
            conn = ConexionDBSingleton.getInstance().getConnection();
        } catch (SQLException e) {
            throw new RuntimeException("Error al conectar con la base de datos", e);
        }
    }

    public List<String> getContinents() {
        List<String> continents = new ArrayList<>();
        String sql = "SELECT DISTINCT Continent FROM country ORDER BY Continent";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                continents.add(rs.getString("Continent"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return continents;
    }

    public List<Country> buscarCountries(String continent, String nameFilter) {
        List<Country> list = new ArrayList<>();
        String sql = "SELECT Code, Name, Continent, Region, Population, GovernmentForm FROM country " +
                     "WHERE Continent LIKE ? AND Name LIKE ? ORDER BY Name";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, continent.isEmpty() ? "%" : continent);
            ps.setString(2, "%" + nameFilter + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Country c = new Country.Builder()
                            .setCode(rs.getString("Code"))
                            .setName(rs.getString("Name"))
                            .setContinent(rs.getString("Continent"))
                            .setRegion(rs.getString("Region"))
                            .setPopulation(rs.getInt("Population"))
                            .setGovernmentForm(rs.getString("GovernmentForm"))
                            .build();
                    list.add(c);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<City> getCitiesCountry(String countryCode) {
        List<City> cities = new ArrayList<>();
        String sql = "SELECT ID, Name, District, Population FROM city WHERE CountryCode = ? ORDER BY Name";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, countryCode);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cities.add(new City(
                            rs.getInt("ID"),
                            rs.getString("Name"),
                            rs.getString("District"),
                            rs.getInt("Population")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cities;
    }
}