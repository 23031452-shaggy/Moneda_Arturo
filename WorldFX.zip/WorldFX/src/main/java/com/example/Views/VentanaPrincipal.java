package com.example.Views;
import com.example.Controllers.Controller;
import com.example.Models.City;
import com.example.Models.Country;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
public class VentanaPrincipal {
    private final Controller controller;
    public VentanaPrincipal(Controller controller) {
        this.controller = controller;
    }
    public void mostrar(Stage stage) {
        ComboBox<String> cmbContinente = new ComboBox<>();
        cmbContinente.setPromptText("Continente");
        TextField txtNombrePais = new TextField();
        Button btnBuscar = new Button("Buscar");
        Button btnCiudades = new Button("Ver Ciudades");

        HBox filtros = new HBox(10, cmbContinente, txtNombrePais, btnBuscar);
        filtros.setPadding(new Insets(10));
        filtros.setAlignment(Pos.CENTER_LEFT);

        TableView<Country> tblPaises = new TableView<>();
        TableColumn<Country, String> colNombre = new TableColumn<>("Nombre");
        TableColumn<Country, String> colContinente = new TableColumn<>("Continente");
        TableColumn<Country, String> colRegion = new TableColumn<>("Region");
        TableColumn<Country, Integer> colPoblacion = new TableColumn<>("Poblacion");
        colNombre.setPrefWidth(210);
        colContinente.setPrefWidth(140);
        colRegion.setPrefWidth(280);
        colPoblacion.setPrefWidth(90);

        colNombre.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getName()));
        colContinente.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getContinent()));
        colRegion.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getRegion()));
        colPoblacion.setCellValueFactory(c -> new javafx.beans.property.SimpleObjectProperty<>(c.getValue().getPopulation()));

        tblPaises.getColumns().addAll(colNombre, colContinente, colRegion, colPoblacion);
        tblPaises.setPrefHeight(300);

        Label lblNombre = new Label("Nombre: ");
        Label lblContinente = new Label("Continente: ");
        Label lblRegion = new Label("Region: ");
        Label lblPoblacion = new Label("Poblacion: ");
        Label lblGobierno = new Label("Gobierno: ");

        VBox panelDetalles = new VBox(10,
                new Label("Detalles del Pais"),
                lblNombre, lblContinente, lblRegion, lblPoblacion, lblGobierno);
        panelDetalles.setPadding(new Insets(15));
        panelDetalles.setPrefWidth(250);

        TableView<City> tblCiudades = new TableView<>();
        TableColumn<City, String> colCiudad = new TableColumn<>("Ciudad");
        TableColumn<City, String> colDistrito = new TableColumn<>("Distrito");
        TableColumn<City, Integer> colPobCiudad = new TableColumn<>("Poblacion");

        colCiudad.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getName()));
        colDistrito.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getDistrict()));
        colPobCiudad.setCellValueFactory(c -> new javafx.beans.property.SimpleObjectProperty<>(c.getValue().getPopulation()));

        colCiudad.setPrefWidth(300);
        colDistrito.setPrefWidth(300);
        colPobCiudad.setPrefWidth(120);

        tblCiudades.getColumns().addAll(colCiudad, colDistrito, colPobCiudad);
        tblCiudades.setPrefHeight(200);

        VBox tablaYBoton = new VBox(10, tblPaises, btnCiudades, tblCiudades);
        tablaYBoton.setPadding(new Insets(10));

        BorderPane layout = new BorderPane();
        layout.setTop(filtros);
        layout.setCenter(tablaYBoton);
        layout.setRight(panelDetalles);

        cmbContinente.setItems(controller.obtenerContinentes());

        btnBuscar.setOnAction(e -> {
            String continente = cmbContinente.getValue() == null ? "" : cmbContinente.getValue();
            String nombre = txtNombrePais.getText().trim();
            tblPaises.setItems(controller.buscarPaises(continente, nombre));
        });

        tblPaises.getSelectionModel().selectedItemProperty().addListener((obs, oldV, pais) -> {
            if (pais != null) {
                lblNombre.setText("Nombre: " + pais.getName());
                lblContinente.setText("Continente: " + pais.getContinent());
                lblRegion.setText("Región: " + pais.getRegion());
                lblPoblacion.setText("Poblacion: " + String.format("%,d", pais.getPopulation()));
                lblGobierno.setText("Gobierno: " + pais.getGovernmentForm());
            }
        });

        btnCiudades.setOnAction(e -> {
            Country pais = tblPaises.getSelectionModel().getSelectedItem();
            tblCiudades.setItems(controller.obtenerCiudades(pais));
        });
        tblPaises.setId("tablaPaises");
        tblCiudades.setId("tablaCiudades");
        Scene scene = new Scene(layout, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("/View.css").toExternalForm());
        stage.setTitle("BASE DE DATOS WORLD");
        stage.setScene(scene);
        stage.setOnCloseRequest(e -> Platform.exit());
        stage.show();
    }
}
